<?php

namespace App\Livewire;

use Livewire\Component;
use Illuminate\Support\Str;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\NumberColumn;
use Mediconesystems\LivewireDatatables\DateColumn;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;
use \SupportPal\ApiClient\Config\ApiContext;
use \SupportPal\ApiClient\SupportPal;

class UserDatatables extends LivewireDatatable
{
    // public function render()
    // {
    //     return view('livewire.user-datatables');
    // }
    public function __construct()
    {
        $this->hostname = config('constant.HOST_NAME');
        $this->apiToken = config('constant.SUPPORT_PAL_ApiToken');
    }

    public function getdata(){

        $context = new ApiContext($this->hostname, $this->apiToken);
        $context->setPath('support');
        $api = new SupportPal($context);
        $tickets =  $api->getTicketApi()->getTickets();

        $count = $tickets->getCount();
        $models = $tickets->getModels();

        return $models;
    }


}
