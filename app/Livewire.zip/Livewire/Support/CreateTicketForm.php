<?php

namespace App\Livewire\Support;

use Livewire\Component;
use Illuminate\Http\Request;
class CreateTicketForm extends Component
{
    public function render(Request $request)
    { 
        $data['user'] = $request->user();
        return view('livewire.support.create-ticket-form',$data);
    }
}
